package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.CampaignUpdateService;
import vo.ActionForward;

public class CampaignUpdateProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String campaign_name = request.getParameter("campaign_name");
		String campaign_content = request.getParameter("campaign_content");
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		
		CampaignUpdateService campaignUpdateService = new CampaignUpdateService();
		boolean isCampaignUpdateSuccess = campaignUpdateService.campaignUpdate(campaign_name, campaign_content, campaign_no);

		if (!isCampaignUpdateSuccess) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('캠페인 수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("campaignUpdateSuccess.page", false);
		}
		return forward;
	}

}
