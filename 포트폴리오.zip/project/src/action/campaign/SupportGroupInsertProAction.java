package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.campaign.SupportGroupInsertService;
import vo.ActionForward;
import vo.campaign.CampaignListBean;

public class SupportGroupInsertProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CampaignListBean supportBean = new CampaignListBean();
		
		supportBean.setCampaign_list_no(Integer.parseInt(request.getParameter("campaign_no")));
		supportBean.setCampaign_list_group(request.getParameter("supportGroup_name"));
		supportBean.setCampaign_list_group_intro(request.getParameter("supportGroup_intro"));
		
		SupportGroupInsertService supportGroupInsertService = new SupportGroupInsertService();
		boolean isSupportGroupInsertSuccess = supportGroupInsertService.supportGroupInsert(supportBean);
		
		if (!isSupportGroupInsertSuccess) {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('지원단체 추가에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("supportGroupInsertSuccess.page", false);
		}
		return forward;
	}

}
