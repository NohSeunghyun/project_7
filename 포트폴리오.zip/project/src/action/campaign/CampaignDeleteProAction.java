package action.campaign;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignDeleteService;
import vo.ActionForward;

public class CampaignDeleteProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String admin_id = request.getParameter("admin_id");
		int campaign_no = Integer.parseInt(request.getParameter("campaign_no"));
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			out.println("<script>");
			out.println("alert('삭제할 권한이 없습니다.\\nA등급만 캠페인 삭제 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			CampaignDeleteService campaignDeleteService = new CampaignDeleteService();
			boolean isCampaignDeleteSuccess = campaignDeleteService.isCampaignDelete(campaign_no);
			
			if (!isCampaignDeleteSuccess) {
				out.println("<script>");
				out.println("alert('캠페인 삭제에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				forward = new ActionForward("campaignDeleteSuccess.page", false);
			}
		}
		return forward;
	}

}
