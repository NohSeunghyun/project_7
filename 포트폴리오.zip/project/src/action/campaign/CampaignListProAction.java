package action.campaign;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.campaign.CampaignListService;
import vo.ActionForward;
import vo.campaign.CampaignBean;

public class CampaignListProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		CampaignListService campaignListService = new CampaignListService();
		ArrayList<CampaignBean> campaignList = campaignListService.getCampaign();
		
		request.setAttribute("campaignList", campaignList);
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		if (admin_id != null) {
			AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
			String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
			if (admin_grade != "") {
				forward = new ActionForward("adminCampaign.page", false);
			} else {
				forward = new ActionForward("memberCampaign.page", false);
			}
		} else {
			forward = new ActionForward("campaign.page", false);
		}
		return forward;
	}

}
