package action.login;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.PhoneSarchIDService;
import vo.ActionForward;

public class PhoneSearchIDProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		String name = request.getParameter("name");
		String phone = request.getParameter("phone1")+"-"+request.getParameter("phone2")+"-"+request.getParameter("phone3");
		
		PhoneSarchIDService phoneSearchIDService = new PhoneSarchIDService();
		String searchID = phoneSearchIDService.searchID(name, phone);
		
		if (searchID == "") {
			response.setContentType("text/html;charset=utf-8");
			PrintWriter out = response.getWriter();
			out.println("<script>");
			out.println("alert('검색결과 해당 핸드폰번호로 가입한 아이디가 없습니다.');");
			out.println("history.back();");
			out.println("</script>");
		} else {
		request.setAttribute("searchID", searchID);
		
		forward = new ActionForward("/login/searchID.jsp", false);
		}
		return forward;
	}

}
