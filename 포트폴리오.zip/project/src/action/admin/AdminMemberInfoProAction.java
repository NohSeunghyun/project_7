package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import action.Action;
import svc.admin.AdminGradeChkService;
import svc.admin.AdminMemberInformationService;
import vo.ActionForward;
import vo.login.AdminMemberBean;

public class AdminMemberInfoProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		HttpSession session = request.getSession();
		String admin_id = (String)session.getAttribute("id");
		
		String id = request.getParameter("member_id");
		
		AdminGradeChkService adminGradeChkService = new AdminGradeChkService();
		String admin_grade = adminGradeChkService.isAdminGrade(admin_id);
		
		if (!admin_grade.equalsIgnoreCase("A")) {
			out.println("<script>");
			out.println("alert('수정할 권한이 없습니다.\\nA등급만 수정 가능합니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			AdminMemberInformationService adminMemberInformationService = new AdminMemberInformationService();
			AdminMemberBean adminInfo = adminMemberInformationService.adminMemberInfo(id);
			
			if (adminInfo == null) {
				out.println("<script>");
				out.println("alert('정보조회에 실패하였습니다.');");
				out.println("window.opener='Self';");
				out.println("window.open('','_parent','');");
				out.println("window.close();");
				out.println("</script>");
			} else {
				request.setAttribute("adminInfo", adminInfo);
				forward = new ActionForward("adminChangeInfoForm.page", false);
			}
		}
		return forward;
	}

}
