package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.UpdateMemberService;
import vo.ActionForward;
import vo.login.AdminMemberBean;

public class UpdateAdminMemberProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		AdminMemberBean adminMemberBean = new AdminMemberBean();
		
		adminMemberBean.setAdmin_id(request.getParameter("member_id"));
		adminMemberBean.setAdmin_name(request.getParameter("member_name"));
		adminMemberBean.setAdmin_phone(request.getParameter("member_phone"));
		
		UpdateMemberService updateMemberService = new UpdateMemberService();
		boolean isUpdateSuccess = updateMemberService.updateAdminMember(adminMemberBean);
		
		if (!isUpdateSuccess) {
			out.println("<script>");
			out.println("alert('회원수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("admin_MemberUpdateSuccess.page", false);
		}
		return forward;
	}

}
