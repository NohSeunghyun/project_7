package action.admin;

import java.io.PrintWriter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import action.Action;
import svc.login.UpdateMemberService;
import vo.ActionForward;
import vo.login.CompanyGroupMemberBean;

public class UpdateComgrpMemberProAction implements Action {

	@Override
	public ActionForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
		ActionForward forward = null;
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter out = response.getWriter();
		
		String category = request.getParameter("member_category");
		String com = request.getParameter("comgrp_name1");
		String grp = request.getParameter("comgrp_name2");
		
		CompanyGroupMemberBean companyGroupMemberBean = new CompanyGroupMemberBean();
		
		companyGroupMemberBean.setComgrp_member_id(request.getParameter("member_id"));
		companyGroupMemberBean.setComgrp_member_category(category);
		if (category.equalsIgnoreCase("c")) {
			companyGroupMemberBean.setComgrp_member_name(com);
		} else if (category.equalsIgnoreCase("g")) {
			companyGroupMemberBean.setComgrp_member_name(grp);
		}
		companyGroupMemberBean.setComgrp_manager_name(request.getParameter("member_name"));
		companyGroupMemberBean.setComgrp_member_companyno(request.getParameter("member_companyno"));
		companyGroupMemberBean.setComgrp_manager_phone(request.getParameter("member_phone"));
		companyGroupMemberBean.setComgrp_member_email(request.getParameter("member_email"));
		
		UpdateMemberService updateMemberService = new UpdateMemberService();
		boolean isUpdateSuccess = updateMemberService.updateComgrpMember(companyGroupMemberBean);
		
		if (!isUpdateSuccess) {
			out.println("<script>");
			out.println("alert('회원수정에 실패하였습니다.');");
			out.println("window.opener='Self';");
			out.println("window.open('','_parent','');");
			out.println("window.close();");
			out.println("</script>");
		} else {
			forward = new ActionForward("admin_MemberUpdateSuccess.page", false);
		}
		return forward;
	}

}
