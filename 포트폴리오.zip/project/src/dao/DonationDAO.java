package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class DonationDAO {
	Connection con = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	String sql = "";
	
	private static DonationDAO donationDAO;
	
	public static DonationDAO getInstance() {
		if (donationDAO == null) {
			donationDAO = new DonationDAO();
		}
		return donationDAO;
	}
	
	public void setConnection(Connection con) {
		this.con = con;
	}
	
	
}
