package svc.admin;

import static db.JdbcUtil.*;

import java.sql.Connection;
import java.util.ArrayList;

import dao.AdminDAO;

import vo.login.AdminMemberBean;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class AllMemberPersonalInformationService {

	//모든 회원정보 조회 전 비밀번호, 핸드폰번호 일치를 통한 본인확인 Service
	public String chkPwPhone(String id, String pw, String phone) {
		String successPwPhone = "";
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			successPwPhone = adminDAO.chkPwPhone(id, pw, phone);
		} catch (Exception e) {
			System.out.println("allMemberInfoChkPwPhoneService 에러" + e);
		} finally {
			close(con);
		}
		return successPwPhone;
	}

	//모든 일반회원 정보조회 Service
	public ArrayList<NormalMemberBean> getNormalMemberList() {
		ArrayList<NormalMemberBean> normalMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			normalMemberList = adminDAO.getNormalMemberList();
		} catch (Exception e) {
			System.out.println("getNormalMemberListService 에러" + e);
		} finally {
			close(con);
		}
		return normalMemberList;
	}

	//모든 기업/단체회원 정보조회 Service
	public ArrayList<CompanyGroupMemberBean> getComgrpMemberList() {
		ArrayList<CompanyGroupMemberBean> comgrpMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			comgrpMemberList = adminDAO.getComgrpMemberList();
		} catch (Exception e) {
			System.out.println("getComgrpMemberListService 에러" + e);
		} finally {
			close(con);
		}
		return comgrpMemberList;
	}

	//모든 관리자 정보조회 Service
	public ArrayList<AdminMemberBean> getAdminMemberList() {
		ArrayList<AdminMemberBean> adminMemberList = null;
		Connection con = null;
		try {
			con = getConnection();
			AdminDAO adminDAO = AdminDAO.getInstance();
			adminDAO.setConnection(con);
			
			adminMemberList = adminDAO.getAdminMemberList();
		} catch (Exception e) {
			System.out.println("getAdminMemberListService에러" + e);
		} finally {
			close(con);
		}
		return adminMemberList;
	}

}
