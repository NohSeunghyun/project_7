package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;
import vo.login.CompanyGroupMemberBean;

public class JoinMembership_ComgrpProService {
	
	//기업/단체 회원가입 Service
	public boolean joinMemberShip(CompanyGroupMemberBean companyGroupMember) throws Exception {
		boolean isJoinMemberShipSuccess = false;
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
			
			int joinMemberShipCount = loginDAO.joinMemberShip_comgrp(companyGroupMember);
			
			if (joinMemberShipCount > 0) {
				commit(con);
				isJoinMemberShipSuccess = true;
			} else rollback(con);
		} catch (Exception e) {
			System.out.println("joinMemberShipComgrpService 에러" + e);
		}finally {
			close(con);
		}
		return isJoinMemberShipSuccess;
	}
}
