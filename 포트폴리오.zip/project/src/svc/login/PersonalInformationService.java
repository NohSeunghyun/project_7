package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;
import vo.login.CompanyGroupMemberBean;
import vo.login.NormalMemberBean;

public class PersonalInformationService {

	//개인정보 전 패스워드 일치를 통한 본인확인 Service
		public String chkPW(String id, String pw) {
			String successPW = "";
			Connection con = null;
			try {
				con = getConnection();
				LoginDAO loginDAO = LoginDAO.getInstance();
				loginDAO.setConnection(con);
				
				successPW = loginDAO.chkPW(id, pw);
			} catch (Exception e) {
				System.out.println("infoChkPWService 에러" + e);
			} finally {
				close(con);
			}
			return successPW;
		}
		
		//일반회원 개인정보 조회 Service
		public NormalMemberBean normalInfo(String id) {
			NormalMemberBean normalInfo = null;
			Connection con = null;
			try {
				con = getConnection();
				LoginDAO loginDAO = LoginDAO.getInstance();
				loginDAO.setConnection(con);
			
				normalInfo = loginDAO.normalInfo(id);
			} catch (Exception e) {
				System.out.println("normalInfoService 에러" + e);
			} finally {
				close(con);
			}
			return normalInfo;
		}

		//기업/단체회원 개인정보 조회 Service
		public CompanyGroupMemberBean comgrpInfo(String id) {
			CompanyGroupMemberBean comgrpInfo = null;
			Connection con = null;
			try {
				con = getConnection();
				LoginDAO loginDAO = LoginDAO.getInstance();
				loginDAO.setConnection(con);
			
				comgrpInfo = loginDAO.comgrpInfo(id);
			} catch (Exception e) {
				System.out.println("comgrpInfoService 에러" + e);
			} finally {
				close(con);
			}
			return comgrpInfo;
		}

}
