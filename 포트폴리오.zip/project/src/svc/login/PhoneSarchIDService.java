package svc.login;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.LoginDAO;

public class PhoneSarchIDService {

	////핸드폰번호로 아이디찾기 Service
	public String searchID(String name, String phone) throws Exception {
		String searchID = "";
		Connection con = null;
		try {
			con = getConnection();
			LoginDAO loginDAO = LoginDAO.getInstance();
			loginDAO.setConnection(con);
	
			searchID = loginDAO.phoneSearchID(name, phone);
		} catch (Exception e) {
			System.out.println("phoneSearchIDService 에러" + e);
		} finally {
			close(con);
		}
		return searchID;
	}
}
