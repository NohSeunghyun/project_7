package svc.campaign;

import static db.JdbcUtil.*;

import java.sql.Connection;

import dao.CampaignDAO;
import vo.campaign.CampaignBean;
import vo.campaign.CampaignListBean;

public class CampaignInformationService {

	//캠페인 수정 전 정보조회 Service
	public CampaignBean getCampaignInfo(int campaign_no) {
		CampaignBean campaignInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignInfo = campaignDAO.getCampaignInfo(campaign_no);
			
		} catch (Exception e) {
			System.out.println("getCampaignInfoService 에러" + e);
		} finally {
			close(con);
		}
		return campaignInfo;
	}

	//지원단체 수정 전 정보조회 Service
	public CampaignListBean getCampaignDetailInfo(int group_no) {
		CampaignListBean campaignDetailInfo = null;
		Connection con = null;
		try {
			con = getConnection();
			CampaignDAO campaignDAO = CampaignDAO.getInstance();
			campaignDAO.setConnection(con);
			
			campaignDetailInfo = campaignDAO.getCampaignDetailInfo(group_no);
			
		} catch (Exception e) {
			System.out.println("getCampaignDetailInfoService 에러" + e);
		} finally {
			close(con);
		}
		return campaignDetailInfo;
	}

}
